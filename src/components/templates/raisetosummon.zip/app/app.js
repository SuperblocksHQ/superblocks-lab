// The object 'Contracts' will be injected here, which contains all data for all contracts, keyed on contract name:
// Contracts['RaiseToSummon'] = {
//  abi: [],
//  address: "0x..",
//  endpoint: "http://...."
// }

function RaiseToSummon(Contract) {
    this.web3 = null;
    this.instance = null;
    this.Contract = Contract;
}

RaiseToSummon.prototype.onReady = function() {
    var that = this;
    $(".loading").show();
    if (typeof window.web3 !== 'undefined' && window.web3.currentProvider) {
        // Wait for Metamask accounts to be available
        this.waitForAccounts(function() {
            that.main();
        });
    } else {
        this.lackingWeb3();
    }
}

RaiseToSummon.prototype.waitForAccounts = function(cb) {
    var that = this;
    if(this.hasAccounts()) {
        cb();
    }
    else {
        // We keep trying since Metamask populates the accounts list
        // after the page has been loaded.
        $(".text").hide();
        $(".lockedmetamask").show();
        setTimeout(function() {that.waitForAccounts()}, 1000);
    }
}

RaiseToSummon.prototype.hasAccounts = function() {
    if (window.web3.eth.accounts.length > 0) {
        return true;
    }
    return false;
}

RaiseToSummon.prototype.main = function() {
    var that = this;
    this.initContract();
    this.isInited(function(isInited) {
        if(!isInited) {
            $(".text").hide();
            $(".noinit").show();
            return;
        }
        that.hasBeenClaimed(function(isClaimed) {
            $(".text").hide();
            if(isClaimed) {
                $(".claimed").show();
                return;
            }
            $("#donatebtn").click(function(e) {
                e.preventDefault();
                that.donate();
            });
            $(".donate").show();
            that.updateStatus();
        });
    });
}

RaiseToSummon.prototype.isInited = function(cb) {
    this.instance.minimumAmountRequired(function (error, result) {
        if (error) {
            $(".text").hide();
            $(".error").show();
            return;
        }
        var minimumAmount = result.toNumber();
        if (minimumAmount == 0) {
            cb(false);
        }
        else {
            cb(true);
        }
    });
}

RaiseToSummon.prototype.hasBeenClaimed = function(cb) {
    var that = this;
    this.instance.hasBeenClaimed(function (error, result) {
        if (error) {
            $(".text").hide();
            $(".error").show();
            return;
        }
        cb(result);
    });
}

RaiseToSummon.prototype.initContract = function() {
    this.web3 = new Web3(window.web3.currentProvider);
    var contract_interface = this.web3.eth.contract(this.Contract.abi);
    this.instance = contract_interface.at(this.Contract.address);
}

RaiseToSummon.prototype.updateStatus = function() {
    var that = this;
    this.instance.minimumAmountRequired(function (error, result) {
        if(error) {
            setTimeout(function() {that.updateStatus()}, 5000);
        }
        else {
            $("#donation_threshold").text(result.toNumber());
            that.instance.totalAmountRaised(function (error, result) {
                if(error) {
                    setTimeout(function() {that.updateStatus()}, 5000);
                }
                else {
                    $("#donation_raised").text(result.toNumber());
                    setTimeout(function() {that.updateStatus()}, 5000);
                }
            });
        }
    });
}

RaiseToSummon.prototype.lackingWeb3 = function() {
    $(".text").hide();
    $(".nometamask").show();
}

RaiseToSummon.prototype.donate = function() {
    var value = parseInt(document.getElementById("donation_value").value);
    if(isNaN(value) || value < 1) {
        alert("Please enter a valid value of wei to donate.");
        return;
    }
    $(".text").hide();
    $(".loading").show();
    // Note: we must refer to the original window.web3 object here to get the Metamask accounts.
    this.instance.donate({ from: window.web3.eth.accounts[0], value: value, gas: "99000", gasPrice: '33000000000' },
        function(error, result) {
            $(".text").hide();
            if (error) {
                console.error(error);
                $(".cancelled").show();
                return;
            }
            $(".thanks").show();
        });
}

var raiseToSummon = new RaiseToSummon(Contracts['RaiseToSummon']);

$(document).ready(function() {
    raiseToSummon.onReady();
});