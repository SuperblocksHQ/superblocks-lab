# CryptoPizza - ERC-721
Example crypto-collectibles DApp which uses ERC-721 standard