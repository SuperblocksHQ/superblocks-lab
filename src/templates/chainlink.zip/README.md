# Empty DApp project

This is a bare bones dapp project containing a smart contract and boilerplate app files to get started.

## Where to go from here

Check out the tutorials to find our more how to build your dapp.
