# Chainlink Project

This template is used to create a smart contract that enables external connectivity with the Chainlink network. It is to be used only with the Ropsten environment. Please see our official docs, linked below, for information on how to create a Chainlinked contract.

## Where to go from here

- [Official Docs](https://docs.chain.link/v1.0/docs/getting-started)
- [Ropsten LINK Faucet](https://ropsten.chain.link/)